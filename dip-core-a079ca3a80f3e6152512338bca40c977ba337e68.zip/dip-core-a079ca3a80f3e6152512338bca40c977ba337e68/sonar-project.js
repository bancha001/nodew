const sonarqubeScanner = require('sonarqube-scanner');
sonarqubeScanner({
  serverUrl: process.env.SONARQUBE,
  options: {
    'sonar.sources': '.',
    'sonar.inclusions': '*/**', // Entry point of your code
    'sonar.projectName': process.env.APPNAME,
  },
}, () => {});
