/* eslint-disable max-len */
const fs = require("fs");
const path = require("path");
const Validator = require("validatorjs");
const backend = require("../dip-core/backend");
const ErrorHandler = require("./utils/ErrrorHandler");
const dipconfig = require("./config/dipconfig.json");
const appconfig = require(path.resolve(__dirname, "../config/appconfig.json"));

exports.pattern = async function(request, h, backendFn) {
  request.logger.info("serving operation:", request.operationId);
  // common cds specific business validations
  if (fs.existsSync(path.resolve(__dirname, "./config/CDSRules.js"))) {
    const rules = require("./config/CDSRules.js");
    const validation = await new Validator(request, rules.rules);
    if (validation.fails()) {
      request.logger.error("business validation failed:", validation.errors);
      throw ErrorHandler.raiseError("CDS400BUS", validation.errors);
    }
  }

  if(request.query['page-size'])
  {
    let paginationRules = {
      'page-size' : 'integer|max:1000',
    }
    const pageValidation = await new Validator(request.query, paginationRules);
    if (pageValidation.fails()) {
      request.logger.error('page validation failed:', pageValidation.errors);
      throw ErrorHandler.raiseError('CDS422BUS', pageValidation.errors);
    }
  }

  if (
    appconfig.ValidateContentTypes &&
    request.method === "post" &&
    request.headers["content-type"] &&
    dipconfig["Valid-Content-Types"].indexOf(
      request.headers["content-type"].toLowerCase()
    ) === -1
  ) {
    throw ErrorHandler.raiseError("CDS415", "Invalid content-type header");
  }
  if (
    appconfig.ValidateAccepts &&
    request.headers["accept"] &&
    request.headers["accept"] !== "*/*" &&
    dipconfig["Valid-Accepts"].indexOf(
      request.headers["accept"].toLowerCase()
    ) === -1
  ) {
    throw ErrorHandler.raiseError("CDS406", "Invalid accept header");
  }

  // operation specific business validations
  if (
    fs.existsSync(
      path.resolve(
        __dirname,
        "../config/rules/" + request.operationId + "Rules.js"
      )
    )
  ) {
    const rules = require("../config/rules/" + request.operationId + "Rules");
    const validation = await new Validator(request, rules.rules);
    if (validation.fails()) {
      request.logger.error("business validation failed:", validation.errors);
      throw ErrorHandler.raiseError("CDS400BUS", validation.errors);
    }
  }

  const mapper = require("../config/mappers/" + request.operationId + "Mapper");
  request.logger.info("mapper acquired.");
  const transformedRequest = await mapper.reqMap(request);
  request.logger.info("mapped backend request");
  let backendResp;
  if (backendFn) {
    request.logger.info("invoking custom backend.");
    backendResp = await backendFn(request, transformedRequest, h);
  } else {
    request.logger.info("invoking default backend");
    backendResp = await backend.invoke(request, transformedRequest);
  }
  request.logger.info("backend response:");
  const transformedResponse = await mapper.respMap(request, backendResp);
  request.logger.info("mapped backend response:");
  return h.response(transformedResponse);
};
