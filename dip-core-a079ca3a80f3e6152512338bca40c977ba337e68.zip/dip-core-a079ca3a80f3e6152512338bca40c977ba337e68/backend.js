/* eslint-disable max-len */
const rp = require('request-promise');
const Boom = require('boom');

exports.invoke = async function(request, transformedRequest, h) {
  try {
    return restResp = await rp(transformedRequest.uri, transformedRequest.options);
  } catch (err) {
    throw Boom.serverUnavailable(err);
  }
};
