const SwaggerParser = require('swagger-parser');

exports.plugin = {
  async register(server, options) {
    server.ext('onPreResponse', async (request, h) => {
      try {
        const {response} = request;
        const api = await SwaggerParser.parse('config/swagger.yaml');
		const majorVersion=api.info.version.split('.');
        const version=parseInt(majorVersion[0]);
        if (response.isBoom) {
          response.output.headers['x-v'] = version;
          return h.continue;
        }
        response.header('x-v', version);
        return h.continue;
      } catch (err) {
        return h.continue;
      }
    });
  },
  name: 'xv-header',
};
