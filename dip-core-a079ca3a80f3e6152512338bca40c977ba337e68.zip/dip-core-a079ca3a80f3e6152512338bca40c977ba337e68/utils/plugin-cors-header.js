exports.plugin = {
  async register(server, options) {
    server.ext('onPreResponse', async (request, h) => {
      try {
        const {response} = request;
        if (response.isBoom) {
          response.output.headers['Access-Control-Allow-Origin'] = '*';
          response.output.headers['Access-Control-Allow-Methods'] = 'GET, PUT, POST, DELETE, HEAD';
          response.output.headers['Access-Control-Allow-Headers'] = 'x-v, Accept, Content-Type, Content-Encoding, Server, Transfer-Encoding';
          return h.continue;
        }
        response.header('Access-Control-Allow-Origin',  '*');
        response.header('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE, HEAD');
        response.header('Access-Control-Allow-Headers', 'x-v, Accept, Content-Type, Content-Encoding, Server, Transfer-Encoding');     
        return h.continue;
      } catch (err) {
        return h.continue;
      }
    });
  },
  name: 'cors-header',
};
