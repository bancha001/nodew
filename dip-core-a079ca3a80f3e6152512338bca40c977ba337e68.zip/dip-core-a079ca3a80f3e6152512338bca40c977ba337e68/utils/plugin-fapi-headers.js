const uuidv4 = require('uuid/v4');

exports.plugin = {
  async register(server, options) {
    server.ext('onPreResponse', async (request, h) => {
      const headerval = request.headers['x-fapi-interaction-id'];
      const {response} = request;

      if (response.isBoom) {
        if (headerval) {
          response.output.headers['x-fapi-interaction-id'] = headerval;
          response.output.headers["Content-Type"] = "application/json";
        } else {
          const generatedUUID = uuidv4();
          response.output.headers['x-fapi-interaction-id'] = generatedUUID;
          response.output.headers["Content-Type"] = "application/json";
        }
      } else {
        if (headerval) {
          response.header('x-fapi-interaction-id', headerval);
          response.header('Content-Type', 'application/json');
        } else {
          const generatedUUID = uuidv4();
          response.header('x-fapi-interaction-id', generatedUUID);
          response.header('Content-Type', 'application/json');
        }
      }

      return h.continue;
    });
  },
  name: 'fapi-headers',
};
