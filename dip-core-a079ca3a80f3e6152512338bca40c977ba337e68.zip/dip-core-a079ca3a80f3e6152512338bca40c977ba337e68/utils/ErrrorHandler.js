/* eslint-disable max-len */
const Boom = require('boom');
const path = require('path');
const appconfig = require(path.resolve(__dirname, '../../config/appconfig.json'));

exports.raiseError = function(appErrorCode, meta, response) {
  let boomError;
  if (appconfig && appconfig.error && appconfig.error[appErrorCode]) {
    if (response && response.isBoom) {
      boomError = response;
    } else {
      boomError = Boom.badRequest('');
    }
    boomError.output.statusCode = appconfig.error[appErrorCode].httpcode;
    delete boomError.output.payload.error;
    delete boomError.output.payload.message;
    boomError.output.payload.error = [];

    const errInstance = {};
    errInstance.code = appconfig.error[appErrorCode].code;
    errInstance.title = appconfig.error[appErrorCode].title;
    errInstance.detail = appconfig.error[appErrorCode].detail;
    errInstance.meta = meta;

    // TODO: update this code to accomodate multiple error objects
    boomError.output.payload.error.push(errInstance);

    delete boomError.output.payload.statusCode;
    throw boomError;
  }
};
const raiseError = module.exports.raiseError = this.raiseError;

exports.preResponse = function(request, h) {
  const response = request.response;
  if (!response.isBoom) {
    return h.continue;
  }

  if (response.output.statusCode === 400 && !Array.isArray(response.output.payload.error)) {
    throw raiseError('CDS400SCM', response.output.payload.message, response);
  }

  if (response.output.statusCode === 404 && !Array.isArray(response.output.payload.error)) {
    throw raiseError('CDS405', response.output.payload.message, response);
  }

  if (response.output.statusCode === 503 && !Array.isArray(response.output.payload.error)) {
    throw raiseError('CDS500GEN', 'generic application error', response);
  }

  return request.response;
};
