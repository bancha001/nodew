
module.exports = {
    coverage: true,
    threshold: 85,
    lint: true,
    paths: ['tests/unit-tests'],
    'coverage-exclude': ['tests']
};