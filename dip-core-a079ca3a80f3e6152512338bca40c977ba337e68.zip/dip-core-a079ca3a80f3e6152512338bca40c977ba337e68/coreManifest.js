/* eslint-disable max-len */

const customPlugins = require('../config/plugins').plugins;
let plugins = [{
  plugin: require('hapi-openapi'),
  options: {
    api: require('path').resolve('./config/swagger.yaml'),
    handlers: require('path').resolve('./handlers'),
    docs: {
      path: 'api-docs', // TODO: disable this route from rest explorere
    },
  },
},
{
  plugin: require('./utils/plugin-xv-header'),
},
{
  plugin: require('hapi-alive'),
  options: {
    path: '/health', // Health route path
    tags: ['health', 'monitor'],
    healthCheck: async function(server) {
      const failed = false;
      if (failed) {
        throw new Error('Server not healthy');
      }
      return await true;
    },
    defaults: {
      responses: {
        healthy: {
          message: {'Status': 'OK'}, // TODO: this message is not getting applied.
        },
      },
    },
  },
},
{
  plugin: require('hapi-pino'),
  options: {
    prettyPrint: process.env.NODE_ENV !== 'production',
    // Redact Authorization headers, see https://getpino.io/#/docs/redaction
    redact: ['req.headers.authorization'],
    level: process.env.LOG_LEVEL || 'debug',
    logRequestStart: true,
    logRouteTags: true,
    logPayload: process.env.NODE_ENV !== 'production',
  },
},
{
  plugin: require('vision'),
},
];

plugins = plugins.concat(customPlugins);

exports.manifest = {
  server: {
    host: '0.0.0.0',
    port: 3001,
  }, register: {
    plugins: plugins,
  },
};
