/* eslint-disable max-len */
const Code = require('@hapi/code');
const Lab = require('@hapi/lab');
const fs = require('fs');
const Boom = require('boom');
const path = require('path');
const sinon = require('sinon');
const rp = require('request-promise');

// const backend = require('../../backend');

const {expect} = Code;
const lab = exports.lab = Lab.script();

lab.experiment('dip-core:', () => {
  lab.before(() => {
    if (!fs.existsSync('../config')) {
      fs.mkdirSync('../config');
      fs.mkdirSync('../config/mappers');
      fs.mkdirSync('../config/rules');
      fs.writeFileSync('../config/mappers/getCustomerDetailMapper.js', 'exports.reqMap = async function(request){\n' +
        '//read config \n' +
        '//var backendReq = {}; \n' +
        '//backendReq.uri = process.env.GC_ENDPOINT; \n' +
        '///backendReq.options = {} \n' +
        '//backendReq.options.headers = {}; \n' +
        '//TODO: get the authorization header from consent - this will identify the customer. \n' +
        'return request; \n' +
        '} \n' +
        '\n' +
        'exports.respMap = async function(response){ \n' +
        'return response; \n' +
        '} \n' +
        '\n' +
        'exports.respMap = async function(request,response){ \n' +
        '//var res={}; \n' +
        '//res = response; \n' +
        'return JSON.stringify(response); \n' +
        '}');
      fs.writeFileSync('../config/rules/getCustomerDetailRules.js', 'exports.rules = {\n' +
        '\'headers.x-v\': \'required|in:123\'\n' +
        '};');
      fs.writeFileSync(path.resolve(__dirname, '../../../config/appconfig.json'), fs.readFileSync(path.resolve(__dirname, 'test-appconfig.json')));
    }
    sinon.stub(rp, 'Request').returns({});
  });

  lab.after(() => {
    // if (fs.existsSync('../config/mappers/getCustomerDetailMapper.js')) {
    //   fs.unlinkSync('../config/mappers/getCustomerDetailMapper.js');
    // }
    // if (fs.existsSync('../config/rules/getCustomerDetailRules.js')) {
    //   fs.unlinkSync('../config/rules/getCustomerDetailRules.js');
    // }
    // if (fs.existsSync('../config/rules/CDSRules.js')) {
    //   fs.unlinkSync('../config/rules/CDSRules.js');
    // }
    // if (fs.existsSync('../config/mappers')) {
    //   fs.rmdirSync('../config/mappers');
    // }
    // if (fs.existsSync('../config/mappers')) {
    //   fs.rmdirSync('../config/rules');
    // }
    if (fs.existsSync('../config')) {
      fs.rmdirSync('../config', {recursive: true});
    }
    rp.Request.restore();
  });
  lab.beforeEach(() => {
  });

  lab.test('success case', async () => {
    const pattern = require('../../pattern');
    // mock request object
    const request = {};
    request.logger = {};
    request.operationId = 'getCustomerDetail';
    request.headers = {};
    request.headers['x-v'] = 123;
    request.uri = 'http://httpstat.us/200';
    request.options = {};
    request.options.headers = {};
    request.options.headers['Accept'] = 'application/json';
    request.logger.info = async function(str) {
    };

    // mock h object
    const h = {};
    h.response = async function(jsonObj) {
      return jsonObj;
    };

    const resp = await pattern.pattern(request, h, null);

    expect(resp).to.exists();
    expect(resp).to.equal({});
  });

  lab.test('failure case - backend endpoint failes', async () => {
    const pattern = require('../../pattern');

    // mock request object
    const request = {};
    request.logger = {};
    request.operationId = 'getCustomerDetail';
    request.headers = {};
    request.headers['x-v'] = 123;
    request.uri = 'http://httpstat.us/400';
    request.options = {};
    request.options.headers = {};
    request.options.headers['Accept'] = 'application/json';
    request.logger.info = async function(str) {
    };

    // mock h object
    const h = {};
    h.response = async function(jsonObj) {
      return jsonObj;
    };

    try {
      rp.Request.restore();
      sinon.stub(rp, 'Request').throws(Boom.internal('dummy error'));
      const resp = await pattern.pattern(request, h, null);
      expect(resp).to.not.exists();
    } catch (err) {
      expect(Boom.isBoom(err));
    }
  });

  lab.test('success case - custom backend function', async () => {
    const pattern = require('../../pattern');

    // mock request object
    const request = {};
    request.logger = {};
    request.operationId = 'getCustomerDetail';
    request.headers = {};
    request.headers['content-type']='application/json';
    request.headers['x-v'] = 123;
    request.uri = 'http://httpstat.us/400';
    request.options = {};
    request.options.headers = {};
    request.options.headers['Accept'] = 'application/json';
    request.logger.info = async function(str) {
    };

    // mock h object
    const h = {};
    h.response = async function(jsonObj) {
      return jsonObj;
    };

    const customFunc = async function(request, transformedRequest, h) {
      try {
        const restResp = await rp(transformedRequest.uri, transformedRequest.options);
        return restResp;
      } catch (err) {
        throw Boom.serverUnavailable(err);
      }
    };
    try {
      const resp = await pattern.pattern(request, h, customFunc);
      expect(resp).to.not.exists();
    } catch (err) {
      expect(Boom.isBoom(err));
    }
  });

  lab.test('failure case - operation specific rule fails', async () => {
    const pattern = require('../../pattern');

    // mock request object
    const request = {};
    request.logger = {};
    request.operationId = 'getCustomerDetail';
    request.headers = {};
    request.headers['x-v'] = 456;
    request.uri = 'http://httpstat.us/400';
    request.options = {};
    request.options.headers = {};
    request.options.headers['Accept'] = 'application/json';
    request.logger.info = async function(str) {
    };
    request.logger.error = async function(str) {
    };

    // mock h object
    const h = {};
    h.response = async function(jsonObj) {
      return jsonObj;
    };

    try {
      const resp = await pattern.pattern(request, h, null);
      expect(resp).to.not.exists();
    } catch (err) {
      expect(err).to.exists();
    }
  });

  lab.test('ErrorHandler.preResponse - Success - no error scenario', async () => {
    const eh = require('../../utils/ErrrorHandler');
    // mock req
    const req = {};
    req.response = {};
    const h = {};
    h.continue = 'dummy';
    const resp = await eh.preResponse(req, h);
    expect(resp).to.equal('dummy');
  });

  lab.test('ErrorHandler.preResponse - Success - pattern based validation failure - 400', async () => {
    const eh = require('../../utils/ErrrorHandler');
    // mock req
    const req = {};
    req.response = Boom.badRequest('bad request error');
    // req.response = {};
    // req.response.output = {};
    // req.response.output.statusCode = 400;

    // req.response.output.payload = {};
    // req.response.output.payload.error = [];
    // req.response.output.payload.error.push('dummy error description');
    const h = {};
    try {
      const resp = await eh.preResponse(req, h);
      expect(resp).to.not.exists();
    } catch (err) {
      expect(err).to.exists();
    }
  });

  lab.test('ErrorHandler.preResponse - Success - pattern based validation failure - 404', async () => {
    const eh = require('../../utils/ErrrorHandler');
    // mock req
    const req = {};
    req.response = Boom.notFound('dummy 404 error');
    // req.response = {};
    // req.response.output = {};
    // req.response.output.statusCode = 400;

    // req.response.output.payload = {};
    // req.response.output.payload.error = [];
    // req.response.output.payload.error.push('dummy error description');
    const h = {};
    try {
      const resp = await eh.preResponse(req, h);
      expect(resp).to.not.exists();
    } catch (err) {
      expect(err).to.exists();
    }
  });

  lab.test('ErrorHandler.preResponse - Success - pattern based validation failure - 503', async () => {
    const eh = require('../../utils/ErrrorHandler');
    // mock req
    const req = {};
    req.response = Boom.serverUnavailable('dummy 504 error');
    // req.response = {};
    // req.response.output = {};
    // req.response.output.statusCode = 400;

    // req.response.output.payload = {};
    // req.response.output.payload.error = [];
    // req.response.output.payload.error.push('dummy error description');
    const h = {};
    try {
      const resp = await eh.preResponse(req, h);
      expect(resp).to.not.exists();
    } catch (err) {
      expect(err).to.exists();
    }
  });

  lab.test('ErrorHandler.preResponse - Success - pattern based validation failure - 401', async () => {
    const eh = require('../../utils/ErrrorHandler');
    // mock req
    const req = {};
    req.response = Boom.unauthorized('dummy 401');
    // req.response = {};
    // req.response.output = {};
    // req.response.output.statusCode = 400;

    // req.response.output.payload = {};
    // req.response.output.payload.error = [];
    // req.response.output.payload.error.push('dummy error description');
    const h = {};
    try {
      const resp = await eh.preResponse(req, h);
      expect(resp).to.not.exists();
    } catch (err) {
      expect(err).to.exists();
    }
  });

  lab.test('content type validation fails', async () => {
    const pattern = require('../../pattern');

    // mock request object
    const request = {};
    request.logger = {};
    request.operationId = 'getCustomerDetail';
    // data for rules
    request.headers = {};
    request.headers['x-v'] = 123;
    request.method = 'post';
    request.headers['content-type'] = 'application/jon';

    // data for backend
    request.uri = 'http://httpstat.us/200';
    request.options = {};
    request.options.headers = {};
    request.options.headers['Accept'] = 'application/json';
    request.logger.info = async function(str) {
    };

    // mock h object
    const h = {};
    h.response = async function(jsonObj) {
      return jsonObj;
    };

    try {
      const resp = await pattern.pattern(request, h, null);
      expect(resp).to.not.exists();
    } catch (err) {
      expect(err).to.exists();
    }
  });

  lab.test('accept header validation fails', async () => {
    const pattern = require('../../pattern');

    // mock request object
    const request = {};
    request.logger = {};
    request.operationId = 'getCustomerDetail';
    // data for rules
    request.headers = {};
    request.headers['x-v'] = 123;
    request.method = 'post';
    request.headers['accept'] = 'application/jon';

    // data for backend
    request.uri = 'http://httpstat.us/200';
    request.options = {};
    request.options.headers = {};
    request.options.headers['Accept'] = 'application/json';
    request.logger.info = async function(str) {
    };

    // mock h object
    const h = {};
    h.response = async function(jsonObj) {
      return jsonObj;
    };

    try {
      const resp = await pattern.pattern(request, h, null);
      expect(resp).to.not.exists();
    } catch (err) {
      expect(err).to.exists();
    }
  });
});
