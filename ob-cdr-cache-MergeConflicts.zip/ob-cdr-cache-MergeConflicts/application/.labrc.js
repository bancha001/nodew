module.exports = {
    coverage: true,
    threshold: 75,
    lint: false,
    paths: ['./tests'],
    reporter: ['console', 'html', 'lcov'],
    output: ['stdout', 'coverage.html', 'lcov.info'],
    'coverage-exclude': ['tests','dip-core']
}; 