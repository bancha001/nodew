/* eslint-disable indent */
const ErrorHandler = require('../dip-core/utils/ErrrorHandler');
const instances = require('hapi-sequelizejs').instances;
const statusService= require('../service/getStatusServiceImpl');
const updateService =require('../service/updateCDRCacheServiceImpl');
const ADR_INPROGRESS_DURATION = 2;
const DH_INPROGRESS_DURATION=6;

const DATABASE_KEY = 'obcdrdb';
var getRefreshTime =  function(refreshDateTimes) {
    var refreshTime='';
    refreshTime = refreshDateTimes.refrsh_dte_tme;
    return refreshTime;
};

var isDataStale =  function(refreshTime,duration) {
    var date = new Date().toISOString();
    if((new Date(date)-new Date(refreshTime)) > duration) {
        return true;
    }
    return false;
};

module.exports.isADRInProgress = async function() {
    try {
        const model = instances.getModel('obcdrdb', 'dataRecipientControlInfo');
        const dataRecipientControlInfo= await model.findOne();
        if(dataRecipientControlInfo === null){
            return false;
        }
        const isInProgress = dataRecipientControlInfo.ctrl_stat.toLowerCase() === 'in progress';
        var duration=ADR_INPROGRESS_DURATION*60*1000;
        return (!isDataStale(dataRecipientControlInfo.audt_last_upd_tmst,duration)) && isInProgress;

    } catch (err) {
        throw ErrorHandler.raiseError('CDS500IGE', err);
    }
};

module.exports.invoke = async function(request) {
    try {
        if(module.exports.invokeDR() || module.exports.invokeDH())
        {
          //TODO: Uncomment and test
         //updateService.invoke();
         return statusService.invoke(request); 
        }
        else
        { 
            return statusService.invoke(request); 
        }
    } catch (err) {
        throw ErrorHandler.raiseError('CDS500IGE', err);
    }
};

/*module.exports.invokeDR = async function() {
    try {
        const model = instances.getModel('obcdrdb', 'dataRecipientControlInfo');
        const refreshDateTimes=await model.findOne({attributes: ['refrsh_dte_tme']});
        var refreshTime= getRefreshTime(refreshDateTimes);
        //var duration=process.env.REFRESH_DURATION_DH;
        //duration is 5 mins
        var duration=ADR_INPROGRESS_DURATION*60*1000;
        return Boolean (isDataStale(refreshTime,duration));

    } catch (err) {
        console.log('in err', err);
        throw ErrorHandler.raiseError('CDS500IGE', err);
    }
};*/

module.exports.invokeDR = async function() {
    try {
        const model = instances.getModel('obcdrdb', 'dataRecipientControlInfo');
        const refreshDateTimes=await model.findOne({attributes: ['refrsh_dte_tme']});
        var refreshTime= getRefreshTime(refreshDateTimes);
        //var duration=process.env.REFRESH_DURATION_DH;
        //duration is 5 mins
        var duration=ADR_INPROGRESS_DURATION*60*1000;
        return Boolean (isDataStale(refreshTime,duration));

    } catch (err) {
        throw ErrorHandler.raiseError('CDS500IGE', err);
    }
};


/*module.exports.invokeDH = async function() {
    try {
        const model = instances.getModel('obcdrdb', 'dataHolderControlInfo');
        const refreshDateTimes=await model.findOne({attributes: ['refrsh_dte_tme']});
        var refreshTime= getRefreshTime(refreshDateTimes);
        //6 hours 
        var duration = DH_INPROGRESS_DURATION*60*60*1000;
        return  Boolean (isDataStale(refreshTime,duration));    
    } catch (err) {
        console.log('in err', err);
        throw ErrorHandler.raiseError('CDS500IGE', err);
    }
};*/

module.exports.invokeDH = async function() {
    try {
        const model = instances.getModel('obcdrdb', 'dataHolderControlInfo');
        const refreshDateTimes=await model.findOne({attributes: ['refrsh_dte_tme']});
        var refreshTime= getRefreshTime(refreshDateTimes);
        //6 hours 
        var duration = DH_INPROGRESS_DURATION*60*60*1000;
        return  Boolean (isDataStale(refreshTime,duration));    
    } catch (err) {
        throw ErrorHandler.raiseError('CDS500IGE', err);
    }
};

module.exports.invokeLegalEntity = async function() {
    try {
        const model = instances.getModel('obcdrdb', 'legalEntityControlInfo');
        const refreshDateTimes=await model.findOne({attributes: ['refrsh_dte_tme']});
        var refreshTime= getRefreshTime(refreshDateTimes);
        var duration = DH_INPROGRESS_DURATION*60*60*1000;
        return Boolean (isDataStale(refreshTime,duration));
    } catch (err) {
        throw ErrorHandler.raiseError('CDS500IGE', err);
    }
};

/*module.exports.invokeDR = async function() {
    try {
        const model = instances.getModel('obcdrdb', 'dataRecipientControlInfo');
        const refreshDateTimes=await model.findOne({attributes: ['refrsh_dte_tme']});
        var refreshTime= getRefreshTime(refreshDateTimes);
        //var duration=process.env.REFRESH_DURATION_DH;
        //duration is 5 mins
        var duration=5*60*1000;
        return Boolean (isDataStale(refreshTime,duration));

    } catch (err) {
        console.log('in err', err);
        throw ErrorHandler.raiseError('CDS500IGE', err);
    }
};*/


module.exports.invokeGetSW = async function(request, h) {
    try {
        const dbSequelize = instances.getDb(DATABASE_KEY).sequelize;
        return dbSequelize.query('SELECT sw_prod_stat FROM adr_sw_prod where ');

    } catch (err) {
        throw ErrorHandler.raiseError('CDS500IGE', err);
    }
};
