/* eslint-disable max-len */
const ErrorHandler = require('../dip-core/utils/ErrrorHandler');
const instances = require('hapi-sequelizejs').instances;
const uuidv4 = require('uuid/v4');
const readService = require('./readCDRCacheServiceImpl');

const httpRequestPromise = require('promise-request-retry');
const CDR_REGISTRY_ENDPOINT = 'http://wiremock.aus-ob-442983326460a9c8264b8ec5b8de42d2-0001.au-syd.containers.appdomain.cloud/cdr-register/v1/banking/data-recipients';
//const CDR_REGISTRY_ENDPOINT = 'http://localhost:8080/cdr-register/v1/banking/data-recipients';
const DATABASE_KEY = 'obcdrdb';
const DATABASE_NAME = 'obadrdevdb';
const DATA_RECIPIENT_DETAIL_MODEL = 'dataRecipientDetail';
const DATA_RECIPIENT_BRAND_DETAIL_MODEL = 'dataRecipientBrandDetail';
const DATA_RECIPIENT_SOFTWARE_PRODUCT_MODEL = 'dataRecipientSoftwareProduct';
const DATA_RECIPIENT_CONTROL_INFO_MODEL = 'dataRecipientControlInfo';
const DEFAULT_READ_SCHEMA = 'schm_cdr_adr_chk1';
const DEFAULT_WRITE_SCHEMA = 'schm_cdr_adr_chk2';
const SET_PATH_STATEMENT =  'ALTER DATABASE ' + DATABASE_NAME + ' SET search_path = ';
const RETRY_INTERVAL = 5*60*1000;

module.exports.invoke = async function(request, h) {
    const isADRInProgress = await readService.isADRInProgress();
    if(isADRInProgress){
        throw ErrorHandler.raiseError('CDS425');
    }
    try {
        let writeSchema = DEFAULT_WRITE_SCHEMA;
        //Table Group 1 (Data Recipient) refresh
        let dataRecipientControlInfo = await readDataRecipientControlInfo();
        if(dataRecipientControlInfo !== null && dataRecipientControlInfo.wrt_schm_nme !== 'undefined'){
            writeSchema = dataRecipientControlInfo.wrt_schm_nme.toLowerCase();
        }else{
            dataRecipientControlInfo = await createDataRecipientControlInfo();
        }
        const dataRecipient = await httpRequestPromise({uri: CDR_REGISTRY_ENDPOINT,json: true, retry: 3, delay: RETRY_INTERVAL });

        const dataRecipientDetail = await instances.getModel(DATABASE_KEY, writeSchema + '.'+DATA_RECIPIENT_DETAIL_MODEL);
        const dataRecipientBrandDetail = await instances.getModel(DATABASE_KEY, writeSchema + '.'+DATA_RECIPIENT_BRAND_DETAIL_MODEL);
        const dataRecipientSoftwareProduct = await instances.getModel(DATABASE_KEY, writeSchema + '.'+DATA_RECIPIENT_SOFTWARE_PRODUCT_MODEL);

        const cacheUpdateOperations = [];
        const dbSequelize = instances.getDb(DATABASE_KEY).sequelize;

        await clearAllDataRecipientSoftwareProducts(dbSequelize, writeSchema);
        await clearAllDataRecipientBrandDetails(dbSequelize, writeSchema);
        await clearAllDataRecipientDetails(dbSequelize, writeSchema);

        return dbSequelize.transaction(function (cdrCacheTransaction) {
            cacheUpdateOperations.push(updateDataRecipientControlInfo(dataRecipientControlInfo,'In Progress',cdrCacheTransaction));
            dataRecipient.data.forEach(detail => {
                cacheUpdateOperations.push(upsertDataRecipientDetail(dataRecipientDetail,detail,cdrCacheTransaction));
                detail.dataRecipientBrands.forEach(brandDetail => {
                    cacheUpdateOperations.push(upsertDataRecipientBrandDetail(dataRecipientBrandDetail,detail,brandDetail,cdrCacheTransaction));
                    brandDetail.softwareProducts.forEach(software => {
                        cacheUpdateOperations.push(upsertDataRecipientSoftwareProduct(dataRecipientSoftwareProduct, software, brandDetail, cdrCacheTransaction));
                    });
                });
            });
            cacheUpdateOperations.push(finalUpdateDataRecipientControlInfo(dataRecipientControlInfo,cdrCacheTransaction));
            cacheUpdateOperations.push(setSearchPath(dbSequelize, writeSchema, cdrCacheTransaction));
           return Promise.all(cacheUpdateOperations);
        });
    } catch (err) {
        console.log('in err', err);
        throw ErrorHandler.raiseError('CDS500PSD', err);
    }
};

function clearAllDataRecipientSoftwareProducts(sequelize, schema){
    return sequelize.query('DELETE FROM '+ schema + '.adr_sw_prod');
}
function clearAllDataRecipientBrandDetails(sequelize, schema){
    return sequelize.query('DELETE FROM '+ schema + '.adr_brnd_detl');
}

function clearAllDataRecipientDetails(sequelize, schema){
    return sequelize.query('DELETE FROM '+ schema + '.adr_detl');
}

function setSearchPath(sequelize, schema, transaction){
    return sequelize.query(SET_PATH_STATEMENT + schema, { transaction: transaction });
}
function createDataRecipientControlInfo(){
    const dataRecipientControlInfo = instances.getModel(DATABASE_KEY, DATA_RECIPIENT_CONTROL_INFO_MODEL);
    return dataRecipientControlInfo.create({
        ctrl_id: '1',
        ctrl_stat: 'In Progress',
        ver: uuidv4(),
        refrsh_dte_tme: new Date(),
        read_schm_nme: DEFAULT_READ_SCHEMA,
        wrt_schm_nme: DEFAULT_WRITE_SCHEMA,
        audt_crt_tmst: new Date(),
        audt_crt_by: 'OB_ADMIN',
        audt_last_upd_tmst: new Date(),
        audt_last_upd_by: 'OB_ADMIN'
    });
}
function finalUpdateDataRecipientControlInfo(model, transaction){

    return model.update({
        ctrl_stat: 'Complete',
        ver: uuidv4(),
        read_schm_nme: model.wrt_schm_nme,
        wrt_schm_nme: model.read_schm_nme,
        refrsh_dte_tme: new Date(),
        audt_last_upd_tmst: new Date()
    },{transaction: transaction});
}
function updateDataRecipientControlInfo(model, status, transaction){

    return model.update({
        ctrl_stat: status,
        audt_last_upd_tmst: new Date()
    },{transaction: transaction});
}

function upsertDataRecipientSoftwareProduct(model,software,brand,transaction){
    return model.create({
        sw_prod_id: software.softwareProductId,
        adr_brnd_id: brand.dataRecipientBrandId,
        sw_prod_nme: software.softwareProductName,
        sw_prod_desc: software.softwareProductDescription,
        logo_uri: software.logoUri,
        sw_prod_stat: software.status,
        audt_crt_tmst: new Date(),
        audt_crt_by: 'OB_AMIN',
        audt_last_upd_tmst: new Date(),
        audt_last_upd_by: 'OB_ADMIN'
    },{transaction: transaction});
}

function upsertDataRecipientBrandDetail(model, detail, brand,transaction){
    return model.create({
        adr_brnd_id: brand.dataRecipientBrandId,
        legal_entity_id: detail.legalEntityId,
        brnd_nme: brand.brandName,
        logo_uri: brand.logoUri,
        adr_stat: brand.status,
        audt_crt_tmst: new Date(),
        audt_crt_by: 'OB_AMIN',
        audt_last_upd_tmst: new Date(),
        audt_last_upd_by: 'OB_ADMIN'
    },{transaction: transaction});
}

function upsertDataRecipientDetail(model,input,transaction){
    return model.create({
        legal_entity_id: input.legalEntityId,
        legal_entity_nme: input.legalEntityName,
        indstry: input.industry,
        logo_uri: input.logoUri,
        adr_stat: input.status,
        last_upd: new Date(),
        audt_crt_tmst: new Date(),
        audt_crt_by: 'OB_AMIN',
        audt_last_upd_tmst: new Date(),
        audt_last_upd_by: 'OB_ADMIN'
    },{transaction: transaction});
}

function readDataRecipientControlInfo() {
    const dataRecipientControlInfo = instances.getModel(DATABASE_KEY, DATA_RECIPIENT_CONTROL_INFO_MODEL);
    return dataRecipientControlInfo.findOne();
}



