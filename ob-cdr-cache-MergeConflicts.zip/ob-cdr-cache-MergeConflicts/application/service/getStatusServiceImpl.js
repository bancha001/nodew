const ErrorHandler = require('../dip-core/utils/ErrrorHandler');
const instances = require('hapi-sequelizejs').instances;

var checkADRStat = async function(request) {
    try {
        const model = instances.getModel('obcdrdb', 'dataRecipientDetail');
        const status=await model.findOne({attributes: ['adr_stat'],
            where: { legal_entity_id: request.query.legalEntityId}});
        var legalEntityStatus=status.adr_stat;
        return legalEntityStatus;
    } catch (err) {
        console.log('in err', err);
        throw ErrorHandler.raiseError('CDS500IGE', err);
    }
};

var checkSoftwareProdStat = async function(request) {
    try {
        const model = instances.getModel('obcdrdb', 'dataRecipientSoftwareProduct');
        const status=await model.findOne({attributes: ['sw_prod_stat'],
            where: { sw_prod_id: request.query.softwareProductId }});
        var softwareProductStatus=status.sw_prod_stat;
        return softwareProductStatus;
    } catch (err) {
        console.log('in err', err);
        throw ErrorHandler.raiseError('CDS500IGE', err);
    }
};


module.exports.invoke = async function(request) {
    try {
        var AdrStatus= await checkADRStat(request);
        var softProsStat= await checkSoftwareProdStat(request);
        var response={};
        response.legalEntityStatus=AdrStatus;
        response.softwareProductStatus=softProsStat;
        return response;
    } catch (err) {
        console.log('in err', err);
        throw ErrorHandler.raiseError('CDS500IGE', err);
    }
};