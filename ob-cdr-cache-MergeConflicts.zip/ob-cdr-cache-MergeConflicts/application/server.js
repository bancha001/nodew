/* eslint-disable no-console */
'use strict';

const Glue = require('@hapi/glue');
const manifest = require('./dip-core/coreManifest').manifest;
const ErrorHandler = require('./dip-core/utils/ErrrorHandler');

const options = {
    relativeTo: __dirname
};
const startServer = async function () {
    try {
        const server = await Glue.compose(manifest, options);
        server.ext('onPreResponse', ErrorHandler.preResponse);
        await server.start();
        // console log allowed here as the pino handle isnt available here.
        console.log('ob-cdr-cache microservice started!');
    }
    catch (err) {
        // console log allowed here as the pino handle isnt available here.
        console.error(err);
        process.exit(1);
    }
};
startServer();
