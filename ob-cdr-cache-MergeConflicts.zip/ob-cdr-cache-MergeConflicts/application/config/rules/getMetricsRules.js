exports.rules = {
    'headers.x-v': ['required', 'string'],
    'headers.x-min-v': 'string',
    'query.period': ['string', 'in:CURRENT,HISTORIC,ALL'],
    'headers.brand': ['required', 'string']
};
