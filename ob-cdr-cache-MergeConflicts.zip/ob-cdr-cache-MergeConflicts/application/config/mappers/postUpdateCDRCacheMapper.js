/* eslint-disable no-unused-vars */
module.exports.reqMap = async function (request) {
    // read config
    var backendReq = {};
    backendReq.uri = {};
    backendReq.options = {};
    backendReq.options.headers = {};
    return backendReq;
};

exports.respMap = async function (request, response) {
    return '';
};
