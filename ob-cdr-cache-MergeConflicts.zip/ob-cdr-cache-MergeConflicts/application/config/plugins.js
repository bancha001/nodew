const seq = require('sequelize');

// Maximum number of connection in pool is 5
// Minimum number of connection in pool is 0
// The maximum time, 30 seconds, that pool will try to get connection before throwing error
// The maximum time, 10 seconds, that a connection can be idle before being released.

const opts = {
    // dialectOptions: {
    //     ssl: 'require'
    // },

    dialectOptions: {
            ssl: false
    },
    // pool: {
    //     max: 5,
    //     min: 0,
    //     acquire: 30000,
    //     idle: 10000
    // }
};

const modelFiles = __dirname.substring(0,__dirname.lastIndexOf('/'))+'/models/*.js';

exports.plugins = [
    {
        plugin: require('hapi-sequelizejs'),
        options: [
            {
                name: 'obcdrdb', // identifier
                models: [modelFiles, __dirname + '/models/*.js'],
                sequelize: new seq.Sequelize(process.env.DATABASE_CLOUD_URL, opts), // sequelize instance
                sync: true, // sync models - default false
                forceSync: false // force sync (drops tables) - default false
            }
        ]
    }
];
