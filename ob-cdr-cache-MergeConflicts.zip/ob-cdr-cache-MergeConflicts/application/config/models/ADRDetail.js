module.exports = function(sequelize, DataTypes) {
    return sequelize.define('dataRecipientDetail', {
        legal_entity_id: {
          type: DataTypes.INTEGER,
          primaryKey: true
        },
        legal_entity_nme: {
          type: DataTypes.STRING(50),
        },
        indstry: DataTypes.STRING(30),
        logo_uri: DataTypes.STRING(50),
        adr_stat: DataTypes.STRING(30),
        last_upd: DataTypes.DATE,
        audt_crt_tmst: DataTypes.DATE,
        audt_crt_by: DataTypes.STRING(50),
        audt_last_upd_tmst: DataTypes.DATE,
        audt_last_upd_by: DataTypes.STRING(50)
    },{timestamps: false, tableName: 'adr_detl', schema: 'schm_cdr_adr_chk1'});
  };
  