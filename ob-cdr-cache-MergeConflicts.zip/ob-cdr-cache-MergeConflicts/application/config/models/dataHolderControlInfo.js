module.exports = function(sequelize, DataTypes) {
  return sequelize.define('dataHolderControlInfo', {
      ctrl_id: {
        type: DataTypes.INTEGER,
        primaryKey: true
      },
      ctrl_stat: {
        type: DataTypes.STRING(20),
        primaryKey: true
      },
      versn: DataTypes.STRING(20),
      refrsh_dte_tme: DataTypes.DATE,
      read_schm_nme: DataTypes.STRING(30),
      wrt_schem_nme: DataTypes.STRING(30),
      audt_crt_tmst: DataTypes.DATE,
      audt_crt_by: DataTypes.STRING(50),
      audt_last_upd_tmst: DataTypes.DATE,
      audt_last_upd_by: DataTypes.STRING(50)
  },{timestamps: false, tableName: 'dh_ctrl_info', schema: 'schm_adr_ctrl'});
};


