module.exports = function(sequelize, DataTypes, schema) {
    return sequelize.define(schema + '.' + 'dataRecipientSoftwareProduct', {
        sw_prod_id: {
            type: DataTypes.STRING(50),
            primaryKey: true
        },
        adr_brnd_id: DataTypes.STRING(50),
        sw_prod_nme: DataTypes.STRING(50),
        sw_prod_desc: DataTypes.STRING(50),
        logo_uri: DataTypes.STRING(250),
        sw_prod_stat: DataTypes.STRING(30),
        audt_crt_tmst: DataTypes.DATE,
        audt_crt_by: DataTypes.STRING(50),
        audt_last_upd_tmst: DataTypes.DATE,
        audt_last_upd_by: DataTypes.STRING(50)
    },{timestamps: false, tableName: 'adr_sw_prod',schema: schema});
};

