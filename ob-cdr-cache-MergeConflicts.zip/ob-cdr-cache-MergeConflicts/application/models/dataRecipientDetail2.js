const commonModel = require('../models/common/dataRecipientDetail');
module.exports = function(sequelize, DataTypes) {
    return commonModel(sequelize,DataTypes,'schm_cdr_adr_chk2');
};
