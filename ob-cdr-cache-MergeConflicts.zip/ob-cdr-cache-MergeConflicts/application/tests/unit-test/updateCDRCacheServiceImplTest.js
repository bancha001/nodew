'use strict';
/*******************************************************************************
 *
 * Unit test cases
 *
 * Contributors:
 *   IBM
 *
 *******************************************************************************/

const Code = require('code');
const Lab = require('lab');
const lab = exports.lab = Lab.script();
const { describe, it, before , after } = lab;
const expect = Code.expect;
const sinon = require('sinon');
const instances = require('hapi-sequelizejs').instances;
const service = require('../../service/updateCDRCacheServiceImpl');
const readCDRCache = require('../../service/readCDRCacheServiceImpl');

var SwaggerObj = {
  "headers": {
    "Content-Type": "application/json",
    "x-v": "1.0"
  }

};

describe('CDR cache service test suite', () => {

  var h = {};

  const findOneResult =
      {
          'wrt_schm_nme': 'schm_cdr_adr_chk2',
          'ctrl_stat': 'in progress',
          'audt_last_upd_tmst': new Date(2020, 0, 27, 13, 30, 0),
          'refrsh_dte_tme': new Date(2020, 0, 27, 13, 30, 0)
      };

  const sequelizeResult = {
    'query': function(arg){},
    'transaction': function(arg){ return {'status': 'success'}}
  };

  sinon.stub(instances, "getModel").returns({
    "update": function(){},
    "findOne": function(){ return findOneResult}
  });
  sinon.stub(instances, "getDb").returns({
    "sequelize": sequelizeResult
  });


  it('return success when invoke update CDR Cache Service', async function (done) {

    var resp = await service.invoke(SwaggerObj, h);
    expect(resp.status).equals('success');
  });

  it('return true for CDR DH Cache Stale', async function (done) {

    var resp = await readCDRCache.invokeDH(SwaggerObj, h);
    expect(resp).equals(true);
  });

  it('return true for CDR ADR Cache Stale', async function (done) {

    var resp = await readCDRCache.invokeDR(SwaggerObj, h);
    expect(resp).equals(true);
  });



});
