const sonarqubeScanner = require('sonarqube-scanner');
sonarqubeScanner({
    serverUrl: process.env.SONARQUBE,
    options: {
        'sonar.sources': '.',
        'sonar.projectKey': 'projectAppName',
        'sonar.inclusions': '*/**', // Entry point of your code
        'sonar.exclusions': 'tests/**,node_modules/**,dip-core/**',
        'sonar.projectName': 'projectAppName',
        'sonar.javascript.lcov.reportPaths': 'lcov.info'
    }
}, () => {});
