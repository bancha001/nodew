/* eslint-disable no-undef */
/* eslint-disable no-console */
const dbQuery = require('../config/dbdata/dbqueries');
const Handlebars = require('handlebars');
const source = require('../config/mustacheTemplate/template').data;

const mapper = require('./mapper');
const date = new Date();
const formatted = date.toISOString();

// render mustache template
var renderMetric = async function(data) {
    var template = Handlebars.compile(source);
    return template(data);
};

// Get data for current day and current month using db queries
var getCurrentData = async function(sequelize, brand) {
    var metricDay = {};
    var metricMonth = {};
    var data = {};
    // extract current day metrics data from DB
    await sequelize
        .query(dbQuery.currentDayquery, {
            replacements: { brand: brand },
            type: sequelize.QueryTypes.SELECT
        })
        .then(metrics => {
            metricDay = metrics;
        });

    // extract current month metrics infor from DB
    await sequelize
        .query(dbQuery.currentMonquery, {
            replacements: { brand: brand },
            type: sequelize.QueryTypes.SELECT
        })
        .then(metrics => {
            metricMonth = metrics;
        });

    await mapper
        .getCurDayData(metricDay, metricMonth, {})
        .then(function(response) {
            data = response;
        });

    return data;
};

// Get previous day and months data using DB queries
var getPreviousData = async function(sequelize, brand, data) {
    var metricPrvDays = {};
    var metricPreMons = {};

    // extract previous days metrics data from DB
    await sequelize
        .query(dbQuery.prevDaysQuery, {
            replacements: { brand: brand },
            type: sequelize.QueryTypes.SELECT
        })
        .then(metrics => {
            metricPrvDays = metrics;
        });
    // extract previous months infor from DB
    await sequelize
        .query(dbQuery.prevMonsquery, {
            replacements: { brand: brand },
            type: sequelize.QueryTypes.SELECT
        })
        .then(metrics => {
            metricPreMons = metrics;
        });
    await mapper
        .getPrvDayData(metricPrvDays, metricPreMons, data)
        .then(function(response) {
            data = response;
        });

    return data;
};

module.exports.getCurrentMetrics = getCurrentMetrics;

// function to extract current data from DB and create mustache template using that data
async function getCurrentMetrics(sequelize, brand, request) {
    var data = await getCurrentData(sequelize, brand);
    // setting reuesttIme in data object which represents RFC3999 format
    data['requestTime'] = formatted;
    request.logger.info('ALL metrics mustache data ::', data);

    // create mustache template from db data and send response
    return renderMetric(data);
}

module.exports.getHistoricMetrics = getHistoricMetrics;
// function to extract previous days and months data from DB and create mustache template using that data
async function getHistoricMetrics(sequelize, brand, request) {
    var data = await getPreviousData(sequelize, brand, {});

    // RFC 3339 format
    data['requestTime'] = formatted;
    request.logger.info('ALL metrics mustache data ::', data);

    return renderMetric(data);
}
// function to extract previous + current data from DB and create mustache template using that data
module.exports.getALLMetrics = async function(sequelize, brand, request) {
    var data = await getCurrentData(sequelize, brand);
    data = await getPreviousData(sequelize, brand, data);
    data['requestTime'] = formatted;
    request.logger.info('ALL metrics mustache data ::', data);
    return renderMetric(data);
};
