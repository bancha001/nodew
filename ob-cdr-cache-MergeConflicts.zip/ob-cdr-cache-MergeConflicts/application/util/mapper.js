'use strict';
// metrics types
var metrics = [
    'availability',
    'performance',
    'sessionCount',
    'averageTps',
    'peakTps',
    'errors',
    'rejections',
    'customerCount',
    'recipientCount'
];
// metrics types which contain subtypes
var metricsSubContains = ['invocations', 'averageResponse'];
var metricsSubType = [
    'unauthenticated',
    'highPriority',
    'lowPriority',
    'unattended',
    'largePayload'
];
var getSubCurMetricsData = async function(metricDay, metricMonth, data) {
    //Extract current Days data for metric which having subtype defined for e.g. averageResponse and invocations in dynamic object
    for (var l = 0; l <= metricsSubContains.length; l++) {
        for (var m = 0; m < metricDay.length; m++) {
            var mtr = metricDay[m];
            if (mtr.mtrccgy === metricsSubContains[l]) {
                for (var n = 0; n <= metricsSubType.length; n++) {
                    if (mtr.mtrcsubcgy === metricsSubType[n]) {
                        data[mtr.mtrccgy + metricsSubType[n] + 'curDay'] = mtr.mtrcval;
                    }
                }
            }
        }
    }
    return data;
};

var getPrvData = async function(mtr, metricsSubType, j, data) {
    // check if the metric subtype is mathed to metric subtype array
    if (mtr.mtrcsubcgy === metricsSubType[j]) {
        if (
            data[mtr.mtrccgy + metricsSubType[j] + 'prvDay'] &&
            data[mtr.mtrccgy + metricsSubType[j] + 'prvDay'].length > 0
        ) {
            data[mtr.mtrccgy + metricsSubType[j] + 'prvDay'].push(mtr.mtrcval);
        } else {
            data[mtr.mtrccgy + metricsSubType[j] + 'prvDay'] = [];
            data[mtr.mtrccgy + metricsSubType[j] + 'prvDay'].push(mtr.mtrcval);
        }
    }
};

var getSubPrvMetricsData = async function(metricDay, metricMonth, data) {
    // extract metric sub type previous days metrics info
    for (var x = 0; x <= metricsSubContains.length; x++) {
        for (var i = 0; i < metricDay.length; i++) {
            var mtr = metricDay[i];
            if (mtr.mtrccgy === metricsSubContains[x]) {
                for (var j = 0; j <= metricsSubType.length; j++) {
                    getPrvData(mtr, metricsSubType, j, data);
                }
            }
        }
    }
    return data;
};

// Transform the current day and current month in mustache data object
exports.getCurDayData = async function(metricDay, metricMonth, data) {
    // Extract current Day and Current month data in dynamic object
    for (var i = 0; i < metricDay.length; i++) {
        for (var j = 0; j <= metrics.length; j++) {
            var mtr = metricDay[i];
            if (metricMonth[0].mtrccgy === metrics[0]) {
                data[metrics[0] + 'curDay'] = metricMonth[0].mtrcval;
            }
            if (mtr.mtrccgy === metrics[j]) {
                data[metrics[j] + 'curDay'] = mtr.mtrcval;
            }
        }
    }

    data = getSubCurMetricsData(metricDay, metricMonth, data);
    return data;
};

//
exports.getPrvDayData = async function(metricDay, metricMonth, data) {
    // extract all previous months data in object
    var array = [];
    for (var k = 0; k < metricMonth.length; k++) {
        var mtr = metricMonth[k];
        array.push(mtr.mtrcval);
        data['avaliablityprvMonths'] = array;
    }

    // extract all previous days data in object
    for (var i = 0; i < metricDay.length; i++) {
        for (var j = 0; j <= metrics.length; j++) {
            var mtrprv = metricDay[i];
            if (mtrprv.mtrccgy === metrics[j]) {
                if (
                    data[metrics[j] + 'prvDay'] &&
                    data[metrics[j] + 'prvDay'].length > 0
                ) {
                    data[metrics[j] + 'prvDay'].push(mtrprv.mtrcval);
                } else {
                    data[metrics[j] + 'prvDay'] = [];
                    data[metrics[j] + 'prvDay'].push(mtrprv.mtrcval);
                }
            }
        }
    }

    data = getSubPrvMetricsData(metricDay, metricMonth, data);

    return data;
};
