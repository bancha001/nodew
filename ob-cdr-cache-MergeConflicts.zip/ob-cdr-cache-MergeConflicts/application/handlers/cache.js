/* eslint-disable no-unused-vars */
'use strict';

const dipPattern = require('../dip-core/pattern');
const service = require('../service/updateCDRCacheServiceImpl');

/**
 * Operations on /admin/register/metadata
 */
module.exports = {
  /**
   * summary: Metadata Update
   * description: Indicate that a critical update to the metadata for Accredited Data Recipients has been made and should be obtained
   * parameters: action, x-v, x-min-v
   * produces:
   * responses: 200
   */
    post: async function metadataUpdate(request, h) {
        request.operationId = 'postUpdateCDRCache';
        //return await dipPattern.pattern(request, h, service.invoke);
        dipPattern.pattern(request, h, service.invoke);
        return h.response().code(200);
    }
};

module.exports.dipPattern = dipPattern;

