/* eslint-disable no-unused-vars */
'use strict';

const dipPattern = require('../../dip-core/pattern');
const readService = require('../../service/readCDRCacheServiceImpl');

/**
 * Operations on /admin/register/metadata
 */
module.exports = {
    /**
   * summary: Metadata Update
   * description: Indicate that a critical update to the metadata for Accredited Data Recipients has been made and should be obtained
   * parameters: action, x-v, x-min-v
   * produces:
   * responses: 200
   */
    get: async function checkStatus(request, h) {
        request.operationId = 'checkStatus';
        return await dipPattern.pattern(request, h, readService.invoke);
    }
};

module.exports.dipPattern = dipPattern;
