export SPSL_ENDPOINT=""
export SONARQUBE=http://vm01.rtp.raleigh.ibm.com:19000
export APPNAME=ob-cdr-adr-cache
export DATABASE_CLOUD_URL=postgres://postgres:L00t6Q29IX@aus-ob-442983326460a9c8264b8ec5b8de42d2-0001.au-syd.containers.appdomain.cloud:31406/obadrdevdb
